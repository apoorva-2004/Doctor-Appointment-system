from django.db import models

# Create your models here.

class UserLogin(models.Model):
    username = models.CharField(max_length=50)
    password = models.CharField(max_length=50)
    utype = models.CharField(max_length=50)

class appointtable(models.Model):
    appo_id = models.CharField(max_length=40)
    patient_id = models.CharField(max_length=40)
    doc_id = models.CharField(max_length=40)
    appo_date = models.CharField(max_length=20)
    time_slot = models.CharField(max_length=20)

class doctable(models.Model):
    doc_id = models.CharField(max_length=40)
    doc_name= models.CharField(max_length=40)
    specialites = models.CharField(max_length=60)
    available_days= models.CharField(max_length=30)
    experenice= models.CharField(max_length=20)
    photo=models.FileField(upload_to='documents/')

class patienttable(models.Model):
    patient_id = models.CharField(max_length=40)
    name=models.CharField(max_length=40)
    DOB= models.CharField(max_length=40)
    gender= models.CharField(max_length=60)
    contact_no= models.CharField(max_length=20)
    address= models.CharField(max_length=40)
    medical_history= models.CharField(max_length=20)

class prescriptiontable(models.Model):
    prescription_id = models.CharField(max_length=40)
    appo_id= models.CharField(max_length=40)
    doc_id= models.CharField(max_length=60)
    patient_id= models.CharField(max_length=20)
    medications= models.CharField(max_length=100)
    instructions= models.CharField(max_length=100)

class paymenttable(models.Model):
    payment_id = models.CharField(max_length=40)
    appo_id= models.CharField(max_length=40)
    patient_id= models.CharField(max_length=60)
    amount= models.CharField(max_length=20)
    payment_method= models.CharField(max_length=20)
    status= models.CharField(max_length=20)

class scheduletable(models.Model):
    schedule_id = models.CharField(max_length=40)
    doc_id= models.CharField(max_length=40)
    title= models.CharField(max_length=60)
    schedule_date= models.CharField(max_length=20)
    schedule_time= models.CharField(max_length=20)

class notification(models.Model):
    date= models.CharField(max_length=40)
    time= models.CharField(max_length=40)
    appo_id= models.CharField(max_length=60)
    details= models.CharField(max_length=100)
    given_by= models.CharField(max_length=20)

class requestappointment(models.Model):
    patient_id= models.CharField(max_length=40)
    doc_id= models.CharField(max_length=40)
    req_date= models.CharField(max_length=60)
    req_time= models.CharField(max_length=20)
    appo_date= models.CharField(max_length=20)
    time = models.CharField(max_length=20)
    status = models.CharField(max_length=20)

class reviewtable(models.Model):
    review_id= models.CharField(max_length=40)
    doc_id= models.CharField(max_length=40)
    patient_id= models.CharField(max_length=60)
    rating= models.CharField(max_length=100)
    comment= models.CharField(max_length=100)




