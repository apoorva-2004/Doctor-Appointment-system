import smtplib

from django.shortcuts import render, redirect
from django.urls import reverse
from django.contrib import messages

# Create your views here.

from  patient.models import UserLogin

from patient.models import appointtable

from patient.models import doctable

from patient.models import patienttable

from patient.models import prescriptiontable

from patient.models import paymenttable

from patient.models import scheduletable

from patient.models import notification

from patient.models import requestappointment

from patient.models import reviewtable
from django.core.files.storage import FileSystemStorage
import os
from doctor.settings import BASE_DIR



def showabout(request):
    return render(request,"about.html")

def showcontact(request):
    return render(request,"contact.html")


def logcheck(request):
    if request.method=="POST":
        username=request.POST.get('t1')
        password = request.POST.get('t2')
        count=UserLogin.objects.filter(username=username).count()
        if count>=1:
            udata=UserLogin.objects.get(username=username)
            request.session['username']=username
            upass=udata.password
            utype=udata.utype
            if upass==password:
                if utype=='frontoffice':
                    return render(request,'frontoffice_home.html')
                if utype=='doctor':
                    return render(request,'doctor_home.html')
                if utype=='patient':
                    return render(request,'patient_home.html')

            else:
                return render(request,'loginpage.html',{'msg':'invalid password'})
        else:
            return render(request, 'loginpage.html', {'msg': 'invalid username'})

    return render(request,'loginpage.html')

def showlogin(request):
    return render(request,"loginpage.html")

def showindex(request):
    return render(request,"index.html")

def showabout(request):
    return render(request,"about.html")

def showcontact(request):
    return render(request, "contact.html")

def changepassword(request):
    uname=request.session['username']
    if request.method == 'POST':
        currentpass = request.POST.get('t1', '')
        newpass = request.POST.get('t2', '')
        confirmpass = request.POST.get('t3', '')

        ucheck = UserLogin.objects.filter(username=uname).values()
        for a in ucheck:
            u = a['username']
            p = a['password']
            if u == uname and currentpass == p:
                if newpass == confirmpass:
                    UserLogin.objects.filter(username=uname).update(password=newpass)
                    base_url=reverse('logcheck')
                    msg='password has been changed successfully'
                    return redirect(base_url,msg=msg)
                else:
                    return render(request, 'changepassword.html',{'msg': 'both the username and password are incorrect'})
            else:
                return render(request, 'changepassword.html',{'msg': 'invalid username'})
    return render(request, 'changepassword.html')

def forgotpassword(request):
    if request.method=="POST":
        s1=request.POST.get('t1')
        msg="your password"
        mail = smtplib.SMTP('smtp.gmail.com', 587)
        mail.ehlo()
        mail.starttls()
        mail.login('rna21286@gmail.com', 'hifv vgkb huae ithk')
        mail.sendmail('rna21286@gmail.com', s1, msg)
        mail.close()

    return render(request, 'forgotpassword.html')

def insertappointtable(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        appointtable.objects.create(appo_id=s1,patient_id=s2,doc_id=s3,appo_date=s4,time_slot=s5)
        p = appointtable.objects.all().order_by('id').last()
        pid = int(p.appo_id) + 1
        return render(request,"appointtableinfo.html",{'pid':pid})
    p = appointtable.objects.all().order_by('id').last()
    pid = int(p.appo_id) + 1
    return render(request, "appointtableinfo.html",{'pid':pid})


def showappoint(request):
    appointdict=appointtable.objects.all()
    return render(request,"viewappoint.html",{'appointdict': appointdict})

def appoint_del(request,pk):
    id=appointtable.objects.get(id=pk)
    id.delete()
    userdict=appointtable.objects.all()
    return render(request,'viewappoint.html',{'appointdict':appointdict})

def insertdoctable(request):
    if request.method == "POST" and request.FILES['myfile']:
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        myfile = request.FILES['myfile']

        fs = FileSystemStorage()
        filename = fs.save(myfile.name, myfile)
        uploaded_file_url = fs.url(filename)
        pat = os.path.join(BASE_DIR, '/media/' + filename)

        doctable.objects.create(doc_id=s1,doc_name=s2,specialites=s3,available_days=s4,experenice=s5,photo=myfile)
        p = doctable.objects.all().order_by('id').last()
        pid = int(p.doc_id) + 1
        return render(request,"doctableinfo.html",{'pid':pid})
    p = doctable.objects.all().order_by('id').last()
    pid = int(p.doc_id) + 1
    return render(request, "doctableinfo.html",{'pid':pid})

def showdoc(request):
    docdict=doctable.objects.all()
    return render(request,"viewdoc.html",{'docdict':docdict})

def doc_del(request,pk):
    id=doctable.objects.get(id=pk)
    id.delete()
    docdict=doctable.objects.all()
    return render(request,'viewdoc.html',{'docdict':docdict})

def doc_update(request, pk):
    doctor = doctable.objects.get(id=pk)
    if request.method == 'POST':
        available_days = request.POST.get('available_days')
        doctor.available_days = available_days
        doctor.save()
        messages.success(request, 'Doctor information updated successfully!')
        return redirect('showdoc')
    return render(request, 'update_doctor.html', {'doctor': doctor})

def insertpatienttable(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        s6 = request.POST.get('t6')
        s7 = request.POST.get('t7')
        patienttable.objects.create(patient_id=s1,name=s2,DOB=s3,gender=s4,contact_no=s5,address=s6,medical_history=s7)
        UserLogin.objects.create(username=s2,password=s5,utype='patient')
        base_url=reverse('logcheck')
        return redirect(base_url)
    p = patienttable.objects.all().order_by('id').last()
    pid = int(p.patient_id) + 1
    return render(request, "pateinttableinfo.html",{'pid':pid})

def showpatient(request):
    patientdict=patienttable.objects.all()
    return render(request,"viewpatient.html",{'patientdict':patientdict})

def patient_del(request,pk):
    id=patienttable.objects.get(id=pk)
    id.delete()
    patientdict=patienttable.objects.all()
    return render(request,'viewpatient.html',{'patientdict':patientdict})


def insertprestable(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        s6 = request.POST.get('t6')
        prescriptiontable.objects.create(prescription_id=s1,appo_id=s2,doc_id=s3,patient_id=s4,medications=s5,instructions=s6)
        p = prescriptiontable.objects.all().order_by('id').last()
        pid = int(p.prescription_id) + 1
        return render(request,"prestableinfo.html",{'pid':pid})
    p = prescriptiontable.objects.all().order_by('id').last()
    pid = int(p.prescription_id) + 1
    return render(request, "prestableinfo.html",{'pid':pid})

def showprescription(request):
    prescriptiondict=prescriptiontable.objects.all()
    return render(request,"viewprescription.html",{'prescriptiondict':prescriptiondict})

def prescription_del(request,pk):
    id=prescriptiontable.objects.get(id=pk)
    id.delete()
    prescriptiondict=prescriptiontable.objects.all()
    return render(request,'viewprescription.html',{'prescriptiondict':prescriptiondict})

def insertpaymenttable(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        s6 = request.POST.get('t6')
        paymenttable.objects.create(payment_id=s1,appo_id=s2,patient_id=s3,amount=s4,payment_method=s5,	status=s6)
        p = paymenttable.objects.all().order_by('id').last()
        pid = int(p.payment_id) + 1
        return render(request,"paymenttableinfo.html",{'pid':pid})
    p = paymenttable.objects.all().order_by('id').last()
    pid = int(p.payment_id) + 1
    return render(request, "paymenttableinfo.html",{'pid':pid})

def showpayment(request):
    paymentdict=paymenttable.objects.all()
    return render(request,"viewpayment.html",{'paymentdict':paymentdict})

def payment_del(request,pk):
    id=paymenttable.objects.get(id=pk)
    id.delete()
    paymentdict=paymenttable.objects.all()
    return render(request,'viewpayment.html',{'paymentdict':paymentdict})

def insertscheduletable(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        scheduletable.objects.create(schedule_id=s1,doc_id=s2,title=s3,schedule_date=s4,scedule_time=s5)
        p =scheduletable.objects.all().order_by('id').last()
        pid = int(p.schedule_id) + 1
        return render(request,"scheduletableinfo.html",{'pid':pid})
    p = scheduletable.objects.all().order_by('id').last()
    pid = int(p.schedule_id) + 1
    return render(request, "scheduletableinfo.html",{'pid':pid})

def showschedule(request):
    scheduledict=scheduletable.objects.all()
    return render(request,"viewschedule.html",{'scheduledict':scheduledict})

def schedule_del(request,pk):
    id=scheduletable.objects.get(id=pk)
    id.delete()
    scheduledict=scheduletable.objects.all()
    return render(request,'viewschedule.html',{'scheduledict':scheduledict})

def insertnotification(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        notification.objects.create(date=s1,time=s2,appo_id=s3,details=s4,given_by=s5)
        return render(request,"notificationinfo.html")
    return render(request, "notificationinfo.html")

def shownotification(request):
    notificationdict=notification.objects.all()
    return render(request,"viewnotification.html",{'notificationdict':notificationdict})

def notification_del(request,pk):
    id=notification.objects.get(id=pk)
    id.delete()
    notificationdict=notification.objects.all()
    return render(request,'viewnotification.html',{'notificationdict':notificationdict})


def insertrequestappoint(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        s6 = request.POST.get('t6')
        s7 = request.POST.get('t7')
        requestappointment.objects.create(patient_id=s1,doc_id=s2,req_date=s3, req_time=s4,appo_date=s5,time=s6,status=s7)
        return render(request,"requestappointinfo.html")
    return render(request, "requestappointinfo.html")


def showrequest(request):
    requestdict=requestappointment.objects.all()
    return render(request,"viewrequest.html",{'requestdict':requestdict})

def request_del(request,pk):
    id=requestappointment.objects.get(id=pk)
    id.delete()
    requestdict=requestappointment.objects.all()
    return render(request,'viewrequest.html',{'requestdict':requestdict})

def insertreview(request):
    if request.method == "POST":
        s1 = request.POST.get('t1')
        s2 = request.POST.get('t2')
        s3 = request.POST.get('t3')
        s4 = request.POST.get('t4')
        s5 = request.POST.get('t5')
        reviewtable.objects.create(review_id=s1,doc_id=s2,patient_id=s3,rating=s4,comment=s5)
        p = reviewtable.objects.all().order_by('id').last()
        pid = int(p.review_id) + 1
        return render(request,"reviewinfo.html",{'pid':pid})
    p = reviewtable.objects.all().order_by('id').last()
    pid = int(p.review_id) + 1
    return render(request, "reviewinfo.html",{'pid':pid})

def showreview(request):
    reviewdict=reviewtable.objects.all()
    return render(request,"viewreview.html",{'reviewdict':reviewdict})

def review_del(request,pk):
    id=reviewtable.objects.get(id=pk)
    id.delete()
    reviewdict=reviewtable.objects.all()
    return render(request,'viewreview.html',{'reviewdict':reviewdict})



def doctor_list(request):
    doctors = doctable.objects.all()
    return render(request, 'doctor_list.html', {'doctors': doctors})

def schedule_list(request):
    doc_id = request.GET.get('doc_id')
    schedules = scheduletable.objects.filter(doc_id=doc_id)
    return render(request, 'schedule_list.html', {'schedules': schedules, 'doc_id': doc_id})

def appointment_create(request, doc_id):
    if request.method == 'POST':
        appo_id = 1
        patient_id = request.POST['patient_id']
        appo_date = request.POST['appo_date']
        time_slot = request.POST['time_slot']
        appointtable.objects.create(
            appo_id=appo_id,
            patient_id=patient_id,
            doc_id=doc_id,
            appo_date=appo_date,
            time_slot=time_slot
        )
        return redirect('payment_create', appo_id=appo_id, patient_id=patient_id)
    return render(request, 'appointment_form.html', {'doc_id': doc_id})

def payment_success(request):
    return render(request, 'qr.html')

def payment_create(request, appo_id, patient_id):
    if request.method == 'POST':
        payment_id = 1
        amount = request.POST['amount']
        payment_method = request.POST['payment_method']
        status = request.POST['status']
        paymenttable.objects.create(
            payment_id=payment_id,
            appo_id=appo_id,
            patient_id=patient_id,
            amount=amount,
            payment_method=payment_method,
            status=status
        )
        return redirect('payment_success')
    return render(request, 'payment_form.html', {'appo_id': appo_id, 'patient_id': patient_id})