"""
URL configuration for doctor project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path

from patient import views


from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    path('logcheck',views.logcheck,name='logcheck'),
    path('showlogin',views.showlogin,name='showlogin'),
    path('showabout',views.showabout,name='showabout'),
    path('showcontact',views.showcontact,name='showcontact'),
    path('forgotpassword', views.forgotpassword, name='forgotpassword'),
    path('',views.showindex,name='showindex'),
    path('changepassword',views.changepassword,name='changepassword'),
    path('insertappointtable',views.insertappointtable,name='insertappointtable'),
    path('insertdoctable',views.insertdoctable,name='insertdoctable'),
    path('insertpatienttable',views.insertpatienttable,name='insertpatienttable'),
    path('insertprestable',views.insertprestable,name='insertprestable'),
    path('insertpaymenttable',views.insertpaymenttable,name='insertpaymenttable'),
    path('insertscheduletable',views.insertscheduletable,name='insertscheduletable'),
    path('insertnotification',views.insertnotification,name='insertnotification'),
    path('insertrequestappoint',views.insertrequestappoint,name='insertrequestappoint'),
    path('insertreview',views.insertreview,name='insertreview'),



    path('showappoint',views.showappoint,name='showappoint'),
    path('showdoc',views.showdoc,name='showdoc'),
    path('showpatient',views.showpatient,name='showpatient'),
    path('showprescription',views.showprescription,name='showprescription'),
    path('showpayment',views.showpayment,name='showpayment'),
    path('shownotification',views.shownotification,name='shownotification'),
    path('showrequest',views.showrequest,name='showrequest'),
    path('showreview',views.showreview,name='showreview'),
    path('showschedule',views.showschedule,name='showschedule'),
    path('showabout',views.showabout,name='showabout'),
path('showcontact',views.showcontact,name='showcontact'),


    path('appoint_del/(?P<pk>\d+)/$', views.appoint_del, name='appoint_del'),
    path('doc_del/(?P<pk>\d+)/$', views.doc_del, name='doc_del'),
    path('doc_update/(?P<pk>\d+)/$', views.doc_update, name='doc_update'),
    path('notification_del/(?P<pk>\d+)/$', views.notification_del, name='notification_del'),
    path('patient_del/(?P<pk>\d+)/$', views.patient_del, name='patient_del'),
    path('payment_del/(?P<pk>\d+)/$', views.payment_del, name='payment_del'),
    path('prescription_del/(?P<pk>\d+)/$', views.prescription_del, name='prescription_del'),
    path('review_del/(?P<pk>\d+)/$', views.review_del, name='review_del'),
    path('schedule_del/(?P<pk>\d+)/$', views.schedule_del, name='schedule_del'),
    path('request_del/(?P<pk>\d+)/$', views.request_del, name='request_del'),

    path('doctor_list/', views.doctor_list, name='doctor_list'),
    path('schedule_list/', views.schedule_list, name='schedule_list'),
    path('appointment_create/<str:doc_id>/', views.appointment_create, name='appointment_create'),
    path('payment_create/<str:appo_id>/<str:patient_id>/', views.payment_create, name='payment_create'),
    path('payment_success/', views.payment_success, name='payment_success'),  # Optional success page
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL,document_root=settings.MEDIA_ROOT)
